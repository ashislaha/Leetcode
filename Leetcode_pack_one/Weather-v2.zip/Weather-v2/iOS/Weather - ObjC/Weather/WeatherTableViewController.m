//
//  WeatherTableViewController.m
//  Weather
//
//  Copyright © 2019 Uber. All rights reserved.
//

#import "WeatherTableViewController.h"

@interface WeatherTableViewController ()

@end

@implementation WeatherTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"DefaultCell"];
    
    WeatherService *service = [[WeatherService alloc] init];
    self.citiesResponse = [service waitForCities];
    GetWeatherForCityResponse *weatherForCityResponse = [service waitForWeatherForCity:@"sanfrancisco"];
    
    
    NSLog(@"%@", self.citiesResponse.cities[0].name);
    NSLog(@"%@", weatherForCityResponse.currentWeather.longDescription);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.citiesResponse.cities.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DefaultCell" forIndexPath:indexPath];
    
    
    cell.textLabel.text = _citiesResponse.cities[indexPath.row].name;
    return cell;
}

@end
