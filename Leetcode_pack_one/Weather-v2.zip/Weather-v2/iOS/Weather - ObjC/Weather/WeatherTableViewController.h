//
//  WeatherTableViewController.h
//  Weather
//
//  Copyright © 2019 Uber. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GetCitiesResponse.h"
#import "WeatherService.h"
#import "GetWeatherForCityResponse.h"

NS_ASSUME_NONNULL_BEGIN

@interface WeatherTableViewController : UITableViewController

@property (nonatomic) GetCitiesResponse *citiesResponse;

@end

NS_ASSUME_NONNULL_END
