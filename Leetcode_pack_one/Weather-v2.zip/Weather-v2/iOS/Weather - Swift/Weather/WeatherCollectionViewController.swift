//
//  WeatherTableViewController.swift
//  Weather
//
//  Copyright © 2018 Uber. All rights reserved.
//

import UIKit

class WeatherCollectionViewController: UICollectionViewController {

    // TODO: fill out stubs

}
