//
//  WeatherTableViewController.swift
//  Weather
//
//  Copyright © 2018 Uber. All rights reserved.
//

import UIKit

class WeatherTableViewController: UITableViewController {

    var citiesResponse: GetCitiesResponse?
	
	var modifiedDataSource: [String: [City]] = [:]
	var countries: [String] = []

	// var viewModel: ViewModel
	
	// view <--> controller <---> viewModel <--> services (DB, service)
	// Testing -- Unit testing --> Service calls (stub) --> we can create dummy model -- call a dummy network
	// viewModel --> I am assume stub <api call> --> completionHanlder Cities (JSON) --> Mock 

    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "DefaultCell")

        let service = WeatherService()
        citiesResponse = service.waitForCities()
		(modifiedDataSource, countries) = calculateCitesBasedOnCountry(citiesResponse)
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
		return countries.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return modifiedDataSource[countries[section]]?.count ?? 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DefaultCell", for: indexPath)
		let country = countries[indexPath.section]
		if let city = modifiedDataSource[country]?[indexPath.row] {
			cell.textLabel?.text = city.name
		}
        return cell
    }
	
	override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
		return countries[section]
	}

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // no-op (for now)
    }
	
	
	// MARK:- private apis
	
	private func calculateCitesBasedOnCountry(_ citiesResponse: GetCitiesResponse?) -> ([String: [City]], [String]) {
		
		guard let response = citiesResponse else { return ([:], []) }
		
		var dict: [String: [City]] = [:]
		
		for eachCity in response.cities {
			
			let country = eachCity.countryName
			if let value = dict[country] {
				dict[country] = value + [eachCity]
				
			} else {
				dict[country] = [eachCity]
			}
			
		}
		
		let countrySorted = dict.keys.sorted()
		return (dict, countrySorted)
	}
}

