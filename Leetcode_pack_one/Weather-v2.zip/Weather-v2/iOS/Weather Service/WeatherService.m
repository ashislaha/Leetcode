//
//  WeatherService.m
//  Weather
//
//  Copyright © 2017 Uber. All rights reserved.
//

#import "WeatherService.h"

@implementation WeatherService

- (GetCitiesResponse *)waitForCities
{
    return [self waitForCities:YES];
}

- (GetCitiesResponse *)waitForCities:(BOOL)randomize
{
    return [self _getCitiesResponse:randomize];
}

-(void)getCities:(BOOL)randomize onCompletion:(WeatherServiceGetCitiesCompletionBlock)completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        GetCitiesResponse *citiesResponse = [self _getCitiesResponse:randomize];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) {
                completion(citiesResponse);
            }
        });
    });
}

- (GetCitiesResponse *)_getCitiesResponse:(BOOL)randomize {
    [self _randomDelay];

    NSString *path = [[NSBundle mainBundle] pathForResource:@"cities" ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSDictionary *citiesDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];

    if (citiesDict) {
        NSMutableArray *cities = [NSMutableArray array];

        NSMutableArray *cityDictionaries = [NSMutableArray arrayWithArray:citiesDict[@"cities"]];


        if (randomize) {
            NSMutableArray *shuffledCityDictionaries = [NSMutableArray array];
            while (cityDictionaries.count > 0) {
                NSUInteger cityIndex = arc4random() % cityDictionaries.count;
                NSDictionary *cityDict = [cityDictionaries objectAtIndex:cityIndex];

                [shuffledCityDictionaries addObject:cityDict];
                [cityDictionaries removeObjectAtIndex:cityIndex];
            }
            cityDictionaries = shuffledCityDictionaries;
        }

        for (NSDictionary *cityDict in cityDictionaries) {
            City *city = [[City alloc] initWithName:cityDict[@"name"]
                                        countryName:cityDict[@"country"]
                                           latitude:cityDict[@"lat"]
                                         longtitude:cityDict[@"long"]];
            [cities addObject:city];
        }

        GetCitiesResponse *response = [[GetCitiesResponse alloc] initWithCities:[cities copy]];
        return response;
    }
    return nil;
}

- (GetWeatherForCityResponse *)waitForWeatherForCity:(NSString *)cityName
{
    return [self _getWeatherForCity:cityName];
}

- (void)getWeatherForCity:(NSString *)cityName onCompletion:(WeatherServiceGetWeatherForCityCompletionBlock)completion {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        GetWeatherForCityResponse *weatherForCityResponse = [self _getWeatherForCity:cityName];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion) {
                completion(weatherForCityResponse);
            }
        });
    });
}

- (GetWeatherForCityResponse *)_getWeatherForCity:(NSString *)cityName
{
    [self _randomDelay];

    NSString *fileName = [cityName stringByReplacingOccurrencesOfString:@" " withString:@""].lowercaseString;
    NSString *path = [[NSBundle mainBundle] pathForResource:fileName ofType:@"json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    if (data == nil) {
        return nil;
    }
    
    NSDictionary *cityDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    
    if (cityDict) {
        CurrentWeather *currentWeather = [[CurrentWeather alloc] initWithLongDescription:cityDict[@"longDescription"]
                                                                        feelsLikeCelsius:cityDict[@"feelsLike"]
                                                                       rainChancePercent:cityDict[@"rainChance"]
                                                                         humidityPercent:cityDict[@"humidity"]
                                                                  airPressureDescription:cityDict[@"airPressure"]
                                                                           windDirection:cityDict[@"wind"][@"direction"]
                                                                               windSpeed:cityDict[@"wind"][@"speed"]];
        
        NSMutableDictionary<NSString *, PredictedWeather *> *predictedWeatherForDays = [NSMutableDictionary dictionary];
        NSDictionary *sevenDaysDict = cityDict[@"sevenDay"];
        for (NSString *key in sevenDaysDict.allKeys) {
            NSDictionary *dayDict = sevenDaysDict[key];
            PredictedWeather *predictedWeather = [[PredictedWeather alloc] initWithMinTempCelsius:dayDict[@"minTemp"]
                                                                                   maxTempCelsius:dayDict[@"maxTemp"]
                                                                                 shortDescription:dayDict[@"shortDescription"]];
            predictedWeatherForDays[key] = predictedWeather;
        }
        GetWeatherForCityResponse *response = [[GetWeatherForCityResponse alloc] initWithCurrentWeather:currentWeather predictedWeatherForDays:[predictedWeatherForDays copy]];
        return response;
    }
    
    return nil;
}

#pragma mark - Private

- (void)_randomDelay
{
    NSInteger randomNumber = arc4random() % 5;
    [NSThread sleepForTimeInterval:randomNumber];
}

@end
